# HW STEPS
## 1
### a
1. Pseudocode + 
2. Java implementation + 
3. Clever pivot selection: select mid  -
### b
1. Pseudocode + 
2. Java implementation + 
3. Clever pivot selection: select mid  -



## 2
### a. 
implement quick sort
### b
test with input, and measure
