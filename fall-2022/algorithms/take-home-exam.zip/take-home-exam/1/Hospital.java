import java.util.Arrays;

public class Hospital {
    public static void main(String[] args) {
        int[] patients = {12, 7, 10, 9, 5, 4, 11, 1, 6, 8, 2};
        // int[] patients = {5, 4, 3, 2};
        // int[] patients = {1, 2, 5};
        System.out.println("Is sorted: "  + Arrays.toString(patients));
        int missingPatient = findMissingPatient(patients, 0, patients.length - 1);
        System.out.println("missing patient is: "  + missingPatient);
        System.out.println("Is sorted: "  + Arrays.toString(patients));
    }

    public static int partition(int[] arr, int low, int high) {
        int pivot = (high + low) / 2;
        int i = low;
        for (int j = low; j < pivot; j++) { 
            if (arr[j] < arr[pivot]) {
                swap(arr, j, i); 
                i++;
            }
        }
        swap(arr, i, pivot);
        return i;
    }

    public static int findMissingPatient(int[] arr, int low, int high) {
        if (low > high) {
            return low + 1;
        }
        int p = partition(arr, low, high);
        // missing on the low
        if (arr[p] - p !=  1) {
            return findMissingPatient(arr, low, p - 1);
        }
        return findMissingPatient(arr, p + 1, high);
    }


    public static void swap(int[] arr, int i,int j) {
        int temp = arr[i];
        arr[i] = arr[j];
        arr[j] = temp;
    }
}
